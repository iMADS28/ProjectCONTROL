// PC Commander - Media Page
const Media = {
  initialized: false,

  init() {
    if (this.initialized) return;
    this.initialized = true;
    this.loadVolume();
    this.loadDevices();

    // Listen for volume updates
    Connection.on('volume_result', (msg) => {
      if (msg.volume !== undefined) {
        this.updateVolumeUI(msg.volume, msg.muted);
      }
    });
  },

  async loadVolume() {
    try {
      const result = await Connection.api('/api/media/volume');
      this.updateVolumeUI(result.volume, result.muted);
    } catch (err) {
      console.error('Failed to load volume:', err);
    }
  },

  async loadDevices() {
    try {
      const devices = await Connection.api('/api/media/devices');
      const el = document.getElementById('audio-devices');
      if (!devices || devices.length === 0) {
        el.innerHTML = '<p style="color:var(--text-tertiary); font-size:0.85rem;">No audio devices found</p>';
        return;
      }
      el.innerHTML = devices.map(d => `
        <div class="info-row">
          <span class="info-label">🔈 ${d.Name || 'Unknown'}</span>
          <span class="info-value" style="color: ${d.Status === 'OK' ? 'var(--success)' : 'var(--text-tertiary)'}">
            ${d.Status || 'Unknown'}
          </span>
        </div>
      `).join('');
    } catch (err) {
      document.getElementById('audio-devices').innerHTML =
        '<p style="color:var(--text-tertiary); font-size:0.85rem;">Failed to load devices</p>';
    }
  },

  updateVolumeUI(volume, muted) {
    const slider = document.getElementById('volume-slider');
    const value = document.getElementById('volume-value');
    const icon = document.getElementById('volume-icon');

    if (slider) slider.value = volume;
    if (value) value.textContent = `${volume}%`;
    if (icon) {
      if (muted || volume === 0) icon.textContent = '🔇';
      else if (volume < 33) icon.textContent = '🔈';
      else if (volume < 66) icon.textContent = '🔉';
      else icon.textContent = '🔊';
    }
  },

  setVolume(level) {
    Connection.send({ type: 'set_volume', level: parseInt(level) });
    const value = document.getElementById('volume-value');
    if (value) value.textContent = `${level}%`;
  },

  async toggleMute() {
    try {
      const result = await Connection.api('/api/media/mute', { method: 'POST' });
      this.updateVolumeUI(
        parseInt(document.getElementById('volume-slider').value),
        result.muted
      );
      Toast.show(result.muted ? 'Muted' : 'Unmuted', 'info');
    } catch (err) {
      Toast.show('Failed to toggle mute', 'error');
    }
  },

  async key(keyName) {
    try {
      const result = await Connection.api(`/api/media/key/${keyName}`, { method: 'POST' });
      if (result.success) {
        Toast.show(`Media: ${keyName.replace('_', ' ')}`, 'info');
      }
    } catch (err) {
      Toast.show('Media key failed', 'error');
    }
  },
};
