// PC Commander - WebSocket Connection Manager
const Connection = {
  ws: null,
  token: null,
  reconnectAttempts: 0,
  maxReconnectAttempts: 10,
  reconnectDelay: 2000,
  messageHandlers: {},
  isConnected: false,

  // Get WebSocket URL based on current location
  getWsUrl() {
    const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${protocol}//${location.host}`;
  },

  // Connect to WebSocket server
  connect() {
    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket(this.getWsUrl());

        this.ws.onopen = () => {
          console.log('[WS] Connected');
          this.reconnectAttempts = 0;
          this.isConnected = true;
          this.updateStatus(true);

          // Auto-auth with saved token
          if (this.token) {
            this.send({ type: 'auth_token', token: this.token });
          }
          resolve();
        };

        this.ws.onmessage = (event) => {
          try {
            const msg = JSON.parse(event.data);
            this.handleMessage(msg);
          } catch (e) {
            console.error('[WS] Parse error:', e);
          }
        };

        this.ws.onclose = () => {
          console.log('[WS] Disconnected');
          this.isConnected = false;
          this.updateStatus(false);
          this.attemptReconnect();
        };

        this.ws.onerror = (err) => {
          console.error('[WS] Error:', err);
          reject(err);
        };
      } catch (err) {
        reject(err);
      }
    });
  },

  // Send message
  send(data) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
      return true;
    }
    return false;
  },

  // Authenticate with PIN
  authenticate(pin) {
    return new Promise((resolve, reject) => {
      this.once('auth_result', (msg) => {
        if (msg.success) {
          this.token = msg.token;
          localStorage.setItem('pc_commander_token', msg.token);
          resolve(msg);
        } else {
          reject(msg);
        }
      });
      this.send({ type: 'auth', pin });
    });
  },

  // Register message handler
  on(type, handler) {
    if (!this.messageHandlers[type]) {
      this.messageHandlers[type] = [];
    }
    this.messageHandlers[type].push(handler);
  },

  // Register one-time handler
  once(type, handler) {
    const wrapper = (msg) => {
      handler(msg);
      this.off(type, wrapper);
    };
    this.on(type, wrapper);
  },

  // Remove handler
  off(type, handler) {
    if (this.messageHandlers[type]) {
      this.messageHandlers[type] = this.messageHandlers[type].filter(h => h !== handler);
    }
  },

  // Handle incoming messages
  handleMessage(msg) {
    const handlers = this.messageHandlers[msg.type];
    if (handlers) {
      handlers.forEach(handler => handler(msg));
    }

    // Global handler for alerts
    if (msg.type === 'alert') {
      Toast.show(msg.alert.message, msg.alert.severity === 'critical' ? 'error' : 'warning');
    }
  },

  // Reconnect logic
  attemptReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.log('[WS] Max reconnect attempts reached');
      return;
    }
    this.reconnectAttempts++;
    const delay = this.reconnectDelay * Math.min(this.reconnectAttempts, 5);
    console.log(`[WS] Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts})`);
    setTimeout(() => this.connect(), delay);
  },

  // Update connection status UI
  updateStatus(connected) {
    const dot = document.getElementById('status-dot');
    const text = document.getElementById('connection-text');
    if (dot) {
      dot.classList.toggle('connected', connected);
    }
    if (text) {
      text.textContent = connected ? 'Connected' : 'Disconnected';
    }
  },

  // Make authenticated API call
  async api(endpoint, options = {}) {
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers,
    };
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }
    const response = await fetch(endpoint, { ...options, headers });
    return response.json();
  },

  // Disconnect
  disconnect() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.token = null;
    localStorage.removeItem('pc_commander_token');
  },
};
