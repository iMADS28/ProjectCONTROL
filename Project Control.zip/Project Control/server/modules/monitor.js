// PC Commander - System Monitoring Module (Optimized)
const si = require('systeminformation');
const os = require('os');

// ============================================
// Caches for static/slow-changing data
// ============================================
let cachedCpuInfo = null;       // CPU model, cores — never changes
let cachedGpuInfo = null;       // GPU info — changes rarely
let cachedDiskInfo = null;      // Disk space — changes slowly
let lastGpuCheck = 0;
let lastDiskCheck = 0;

const GPU_CACHE_DURATION = 30000;   // Refresh GPU info every 30 seconds
const DISK_CACHE_DURATION = 30000;  // Refresh disk info every 30 seconds

const monitor = {
  // Initialize static info (call once at startup)
  async initStaticInfo() {
    try {
      cachedCpuInfo = await si.cpu();
      console.log('[Monitor] Static CPU info cached:', cachedCpuInfo.manufacturer, cachedCpuInfo.brand);
    } catch (err) {
      console.error('[Monitor] Failed to cache CPU info:', err.message);
    }
  },

  async getStats() {
    try {
      // Only fetch DYNAMIC data every poll cycle
      const [mem, networkStats, cpuTemp, currentLoad] = await Promise.all([
        si.mem(),
        si.networkStats(),
        si.cpuTemperature(),
        si.currentLoad(),
      ]);

      // GPU info (cached, refresh every 30s)
      if (!cachedGpuInfo || Date.now() - lastGpuCheck > GPU_CACHE_DURATION) {
        try {
          cachedGpuInfo = await si.graphics();
          lastGpuCheck = Date.now();
        } catch (e) {
          cachedGpuInfo = { controllers: [] };
        }
      }

      // Disk info (cached, refresh every 30s)
      if (!cachedDiskInfo || Date.now() - lastDiskCheck > DISK_CACHE_DURATION) {
        try {
          cachedDiskInfo = await si.fsSize();
          lastDiskCheck = Date.now();
        } catch (e) {
          cachedDiskInfo = [];
        }
      }

      // CPU info (static, cached forever)
      const cpu = cachedCpuInfo || { manufacturer: '', brand: 'Unknown', speed: 0 };

      // CPU usage
      const cpuUsage = Math.round(currentLoad.currentLoad * 100) / 100;
      const cpuCores = os.cpus().length;

      // Memory info
      const totalMem = mem.total;
      const usedMem = mem.active;
      const memUsage = Math.round((usedMem / totalMem) * 10000) / 100;

      // Disk info
      const disks = (cachedDiskInfo || []).map(disk => ({
        fs: disk.fs,
        mount: disk.mount,
        type: disk.type,
        size: disk.size,
        used: disk.used,
        available: disk.available,
        usage: Math.round(disk.use * 100) / 100,
      }));

      // Network info
      const network = networkStats.map(net => ({
        iface: net.iface,
        rxSec: net.rx_sec || 0,
        txSec: net.tx_sec || 0,
        rxTotal: net.rx_bytes || 0,
        txTotal: net.tx_bytes || 0,
      }));

      // GPU info
      const gpuInfo = cachedGpuInfo && cachedGpuInfo.controllers
        ? cachedGpuInfo.controllers.map(g => ({
            model: g.model,
            vendor: g.vendor,
            vram: g.vram,
            temperatureGpu: g.temperatureGpu,
            utilizationGpu: g.utilizationGpu,
            memoryUsed: g.memoryUsed,
            memoryTotal: g.memoryTotal,
          }))
        : [];

      return {
        timestamp: Date.now(),
        cpu: {
          model: cpu.manufacturer + ' ' + cpu.brand,
          speed: cpu.speed,
          cores: cpuCores,
          usage: cpuUsage,
          temperature: cpuTemp.main || null,
        },
        memory: {
          total: totalMem,
          used: usedMem,
          free: mem.free,
          usage: memUsage,
        },
        gpu: gpuInfo,
        disks,
        network,
        uptime: os.uptime(),
        hostname: os.hostname(),
        platform: os.platform(),
        arch: os.arch(),
      };
    } catch (err) {
      console.error('Monitor error:', err.message);
      return { error: err.message };
    }
  },

  async getProcessList() {
    const processes = await si.processes();
    return processes.list
      .sort((a, b) => b.cpu - a.cpu)
      .map(p => ({
        pid: p.pid,
        name: p.name,
        cpu: Math.round(p.cpu * 100) / 100,
        mem: Math.round(p.mem * 100) / 100,
        memRss: p.memRss,
        state: p.state,
        started: p.started,
        command: p.command,
      }));
  },
};

module.exports = monitor;
