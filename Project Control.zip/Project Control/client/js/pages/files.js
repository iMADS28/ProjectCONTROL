// PC Commander - File Browser Page
const FilesPage = {
  initialized: false,
  currentPath: '',

  init() {
    if (this.initialized) return;
    this.initialized = true;
    this.loadRoots();
  },

  async loadRoots() {
    try {
      const roots = await Connection.api('/api/files/roots');
      this.renderBreadcrumb([{ name: '🏠 Roots', path: '' }]);

      const el = document.getElementById('file-list');
      el.innerHTML = roots.map(r => `
        <div class="file-item" onclick="FilesPage.navigate('${r.path.replace(/\\/g, '\\\\')}')">
          <span class="file-icon">📂</span>
          <div class="file-info">
            <div class="file-name">${r.name}</div>
            <div class="file-meta">${r.path}</div>
          </div>
        </div>
      `).join('');
    } catch (err) {
      document.getElementById('file-list').innerHTML =
        '<p style="color:var(--text-tertiary); padding:20px;">Failed to load roots</p>';
    }
  },

  async navigate(dirPath) {
    try {
      const result = await Connection.api(`/api/files/list?path=${encodeURIComponent(dirPath)}`);
      if (!result.success) {
        Toast.show(result.error || 'Access denied', 'error');
        return;
      }

      this.currentPath = result.path;
      this.renderBreadcrumb(this.buildBreadcrumb(result.path));
      this.renderFiles(result.items, result.path, result.parent);
    } catch (err) {
      Toast.show('Failed to browse: ' + err.message, 'error');
    }
  },

  buildBreadcrumb(filepath) {
    const parts = filepath.split(/[/\\]/).filter(Boolean);
    const crumbs = [{ name: '🏠', path: '' }];
    let current = '';
    parts.forEach(part => {
      current += part + '\\';
      crumbs.push({ name: part, path: current });
    });
    return crumbs;
  },

  renderBreadcrumb(crumbs) {
    const el = document.getElementById('file-breadcrumb');
    el.innerHTML = crumbs.map((c, i) => {
      const separator = i > 0 ? '<span class="breadcrumb-separator">›</span>' : '';
      return `${separator}<span class="breadcrumb-item" onclick="FilesPage.navigate('${c.path.replace(/\\/g, '\\\\')}')">${c.name}</span>`;
    }).join('');
  },

  renderFiles(items, currentPath, parentPath) {
    const el = document.getElementById('file-list');

    // Add "Go up" entry
    let html = '';
    if (parentPath && parentPath !== currentPath) {
      html += `
        <div class="file-item" onclick="FilesPage.navigate('${parentPath.replace(/\\/g, '\\\\')}')">
          <span class="file-icon">⬆️</span>
          <div class="file-info">
            <div class="file-name">..</div>
            <div class="file-meta">Go up</div>
          </div>
        </div>
      `;
    }

    html += items.map(item => {
      const icon = item.isDirectory ? '📁' : this.getFileIcon(item.extension);
      const size = item.size !== null ? this.formatSize(item.size) : '';
      const escapedPath = (item.path || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");

      const actions = item.isDirectory ? '' : `
        <div class="file-actions">
          <button class="file-action-btn" onclick="event.stopPropagation(); FilesPage.download('${escapedPath}')" title="Download">📥</button>
        </div>
      `;

      const onclick = item.isDirectory
        ? `FilesPage.navigate('${escapedPath}')`
        : '';

      return `
        <div class="file-item" ${onclick ? `onclick="${onclick}"` : ''}>
          <span class="file-icon">${icon}</span>
          <div class="file-info">
            <div class="file-name">${item.name}</div>
            <div class="file-meta">${size}${item.error ? ' • ⚠️ ' + item.error : ''}</div>
          </div>
          ${actions}
        </div>
      `;
    }).join('');

    el.innerHTML = html || '<p style="color:var(--text-tertiary); padding:20px; text-align:center;">Empty folder</p>';
  },

  getFileIcon(ext) {
    const icons = {
      '.txt': '📄', '.md': '📝', '.pdf': '📕',
      '.doc': '📝', '.docx': '📝', '.xls': '📊', '.xlsx': '📊',
      '.ppt': '📽️', '.pptx': '📽️',
      '.jpg': '🖼️', '.jpeg': '🖼️', '.png': '🖼️', '.gif': '🖼️',
      '.svg': '🎨', '.bmp': '🖼️', '.webp': '🖼️',
      '.mp3': '🎵', '.wav': '🎵', '.flac': '🎵', '.ogg': '🎵',
      '.mp4': '🎬', '.avi': '🎬', '.mkv': '🎬', '.mov': '🎬',
      '.zip': '📦', '.rar': '📦', '.7z': '📦', '.tar': '📦',
      '.exe': '⚙️', '.msi': '⚙️',
      '.js': '💛', '.ts': '💙', '.py': '🐍', '.html': '🌐',
      '.css': '🎨', '.json': '📋',
      '.dll': '🔧', '.sys': '🔧',
      '.iso': '💿', '.img': '💿',
    };
    return icons[ext] || '📄';
  },

  formatSize(bytes) {
    if (!bytes) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    let size = bytes;
    while (size >= 1024 && i < units.length - 1) { size /= 1024; i++; }
    return `${size.toFixed(1)} ${units[i]}`;
  },

  download(filePath) {
    const url = `/api/files/download?path=${encodeURIComponent(filePath)}`;
    const a = document.createElement('a');
    a.href = url;
    a.download = '';
    // Add auth header via fetch
    fetch(url, {
      headers: { 'Authorization': `Bearer ${Connection.token}` }
    })
    .then(res => res.blob())
    .then(blob => {
      const url = URL.createObjectURL(blob);
      a.href = url;
      a.download = filePath.split('\\').pop();
      a.click();
      URL.revokeObjectURL(url);
      Toast.show('Download started', 'success');
    })
    .catch(err => Toast.show('Download failed', 'error'));
  },
};
