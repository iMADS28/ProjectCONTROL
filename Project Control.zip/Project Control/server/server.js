// PC Commander - Main Server
const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const cors = require('cors');

const config = require('./config');
const { verifyPin, verifyToken, authMiddleware } = require('./utils/auth');
const power = require('./modules/power');
const monitor = require('./modules/monitor');
const media = require('./modules/media');
const input = require('./modules/input');
const apps = require('./modules/apps');
const screenshotModule = require('./modules/screenshot');
const files = require('./modules/files');
const clipboard = require('./modules/clipboard');
const alerts = require('./modules/alerts');

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(config.CLIENT_PATH));

// File upload config
const upload = multer({
  dest: config.UPLOAD_DIR,
  limits: { fileSize: 500 * 1024 * 1024 }, // 500MB max
});

// ===========================
// REST API Routes
// ===========================

// Auth
app.post('/api/auth', (req, res) => {
  const { pin } = req.body;
  const result = verifyPin(pin);
  res.json(result);
});

// Power controls
app.post('/api/power/:action', authMiddleware, async (req, res) => {
  try {
    const { action } = req.params;
    let result;
    switch (action) {
      case 'shutdown': result = await power.shutdown(); break;
      case 'restart': result = await power.restart(); break;
      case 'sleep': result = await power.sleep(); break;
      case 'hibernate': result = await power.hibernate(); break;
      case 'lock': result = await power.lock(); break;
      case 'logoff': result = await power.logoff(); break;
      case 'cancel': result = await power.cancelShutdown(); break;
      case 'schedule':
        result = await power.scheduleShutdown(req.body.seconds || 3600);
        break;
      case 'wol':
        result = await power.wakeOnLan(req.body.mac);
        break;
      default: result = { success: false, error: 'Unknown action' };
    }
    res.json(result);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Media controls
app.get('/api/media/volume', authMiddleware, async (req, res) => {
  res.json(await media.getVolume());
});

app.post('/api/media/volume', authMiddleware, async (req, res) => {
  res.json(await media.setVolume(req.body.level));
});

app.post('/api/media/mute', authMiddleware, async (req, res) => {
  res.json(await media.toggleMute());
});

app.post('/api/media/key/:key', authMiddleware, async (req, res) => {
  try {
    res.json(await media.sendMediaKey(req.params.key));
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/media/devices', authMiddleware, async (req, res) => {
  try {
    res.json(await media.getAudioDevices());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Screenshot
app.get('/api/screenshot', authMiddleware, async (req, res) => {
  const result = await screenshotModule.captureBase64();
  res.json(result);
});

app.get('/api/screenshots', authMiddleware, (req, res) => {
  res.json(screenshotModule.getList());
});

app.get('/api/screenshot/file/:filename', authMiddleware, (req, res) => {
  const filepath = path.join(config.SCREENSHOT_DIR, req.params.filename);
  if (fs.existsSync(filepath)) {
    res.sendFile(filepath);
  } else {
    res.status(404).json({ error: 'Screenshot not found' });
  }
});

// Apps
app.get('/api/apps', authMiddleware, async (req, res) => {
  try {
    res.json(await apps.getInstalledApps());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/apps/launch', authMiddleware, async (req, res) => {
  try {
    res.json(await apps.launchApp(req.body.target));
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/apps/open-url', authMiddleware, async (req, res) => {
  try {
    res.json(await apps.openUrl(req.body.url));
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Processes
app.get('/api/processes', authMiddleware, async (req, res) => {
  try {
    res.json(await apps.getProcesses());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/processes/:pid', authMiddleware, async (req, res) => {
  try {
    res.json(await apps.killProcess(req.params.pid));
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Files
app.get('/api/files/roots', authMiddleware, (req, res) => {
  res.json(files.getRoots());
});

app.get('/api/files/list', authMiddleware, (req, res) => {
  const dirPath = req.query.path || require('os').homedir();
  res.json(files.listDirectory(dirPath));
});

app.get('/api/files/download', authMiddleware, (req, res) => {
  const filePath = req.query.path;
  if (!filePath || !fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'File not found' });
  }
  res.download(filePath);
});

app.post('/api/files/upload', authMiddleware, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const destDir = req.body.destination || config.UPLOAD_DIR;
  const destPath = path.join(destDir, req.file.originalname);
  fs.renameSync(req.file.path, destPath);
  res.json({ success: true, message: `Uploaded: ${req.file.originalname}`, path: destPath });
});

app.delete('/api/files', authMiddleware, (req, res) => {
  res.json(files.deleteItem(req.body.path));
});

app.post('/api/files/mkdir', authMiddleware, (req, res) => {
  res.json(files.createDirectory(req.body.path));
});

app.post('/api/files/rename', authMiddleware, (req, res) => {
  res.json(files.renameItem(req.body.path, req.body.newName));
});

// Clipboard
app.get('/api/clipboard', authMiddleware, async (req, res) => {
  try {
    res.json(await clipboard.read());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/clipboard', authMiddleware, async (req, res) => {
  try {
    res.json(await clipboard.write(req.body.content));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/clipboard', authMiddleware, async (req, res) => {
  try {
    res.json(await clipboard.clear());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Alerts
app.get('/api/alerts', authMiddleware, (req, res) => {
  res.json({
    active: alerts.activeAlerts,
    history: alerts.getHistory(),
    thresholds: alerts.thresholds,
  });
});

app.post('/api/alerts/thresholds', authMiddleware, (req, res) => {
  res.json(alerts.updateThresholds(req.body));
});

app.delete('/api/alerts/history', authMiddleware, (req, res) => {
  res.json(alerts.clearHistory());
});

// Input - hotkey presets
app.get('/api/input/presets', authMiddleware, (req, res) => {
  res.json(input.presets);
});

// ===========================
// WebSocket Handling
// ===========================

const connectedClients = new Set();
let monitorInterval = null;

// Mouse move throttling — max 1 move per 30ms per client
const mouseThrottles = new WeakMap();

wss.on('connection', (ws) => {
  let authenticated = false;

  ws.on('message', async (data) => {
    try {
      const msg = JSON.parse(data);

      // Authentication
      if (msg.type === 'auth') {
        const result = verifyPin(msg.pin);
        ws.send(JSON.stringify({ type: 'auth_result', ...result }));
        if (result.success) {
          authenticated = true;
          ws.token = result.token;
          connectedClients.add(ws);
          startMonitoring();
          console.log(`[+] Client authenticated (${connectedClients.size} total)`);
        }
        return;
      }

      // Token auth for reconnection
      if (msg.type === 'auth_token') {
        const result = verifyToken(msg.token);
        ws.send(JSON.stringify({ type: 'auth_result', success: result.valid, error: result.error }));
        if (result.valid) {
          authenticated = true;
          ws.token = msg.token;
          connectedClients.add(ws);
          startMonitoring();
        }
        return;
      }

      // All other messages require authentication
      if (!authenticated) {
        ws.send(JSON.stringify({ type: 'error', message: 'Not authenticated' }));
        return;
      }

      // Handle commands
      switch (msg.type) {
        // Input commands (real-time via WebSocket)
        case 'key_press':
          ws.send(JSON.stringify({ type: 'input_result', ...await input.keyPress(msg.key) }));
          break;

        case 'hotkey':
          ws.send(JSON.stringify({ type: 'input_result', ...await input.hotkey(msg.keys) }));
          break;

        case 'type_text':
          ws.send(JSON.stringify({ type: 'input_result', ...await input.typeText(msg.text) }));
          break;

        case 'mouse_move': {
          const now = Date.now();
          const lastMove = mouseThrottles.get(ws) || 0;
          if (now - lastMove < 30) break; // Throttle: skip if < 30ms since last move
          mouseThrottles.set(ws, now);
          input.mouseMove(msg.dx, msg.dy); // Fire-and-forget, don't await
          break;
        }

        case 'mouse_click':
          ws.send(JSON.stringify({ type: 'input_result', ...await input.mouseClick(msg.button) }));
          break;

        case 'mouse_scroll':
          ws.send(JSON.stringify({ type: 'input_result', ...await input.mouseScroll(msg.amount) }));
          break;

        case 'mouse_position':
          ws.send(JSON.stringify({ type: 'mouse_position', ...await input.getMousePosition() }));
          break;

        case 'preset_hotkey':
          const preset = input.presets[msg.name];
          if (preset) {
            ws.send(JSON.stringify({ type: 'input_result', ...await input.hotkey(preset) }));
          } else {
            ws.send(JSON.stringify({ type: 'error', message: `Unknown preset: ${msg.name}` }));
          }
          break;

        // Volume (real-time slider)
        case 'set_volume':
          ws.send(JSON.stringify({ type: 'volume_result', ...await media.setVolume(msg.level) }));
          break;

        case 'get_volume':
          ws.send(JSON.stringify({ type: 'volume_result', ...await media.getVolume() }));
          break;

        default:
          ws.send(JSON.stringify({ type: 'error', message: `Unknown command: ${msg.type}` }));
      }
    } catch (err) {
      ws.send(JSON.stringify({ type: 'error', message: err.message }));
    }
  });

  ws.on('close', () => {
    connectedClients.delete(ws);
    console.log(`[-] Client disconnected (${connectedClients.size} remaining)`);
    if (connectedClients.size === 0) {
      stopMonitoring();
    }
  });

  ws.on('error', (err) => {
    console.error('WebSocket error:', err.message);
    connectedClients.delete(ws);
  });
});

// System monitoring broadcast
function startMonitoring() {
  if (monitorInterval) return;
  monitorInterval = setInterval(async () => {
    if (connectedClients.size === 0) {
      stopMonitoring();
      return;
    }
    try {
      const stats = await monitor.getStats();
      const alertsData = alerts.checkStats(stats);
      const payload = JSON.stringify({
        type: 'system_stats',
        stats,
        alerts: alertsData,
      });
      connectedClients.forEach(client => {
        if (client.readyState === 1) { // WebSocket.OPEN
          client.send(payload);
        }
      });
    } catch (err) {
      console.error('Monitoring error:', err.message);
    }
  }, config.MONITOR_INTERVAL);
}

function stopMonitoring() {
  if (monitorInterval) {
    clearInterval(monitorInterval);
    monitorInterval = null;
  }
}

// Alert notifications
alerts.onAlert((alert) => {
  const payload = JSON.stringify({ type: 'alert', alert });
  connectedClients.forEach(client => {
    if (client.readyState === 1) {
      client.send(payload);
    }
  });
});

// ===========================
// Serve client app
// ===========================
app.get('*', (req, res) => {
  res.sendFile(path.join(config.CLIENT_PATH, 'index.html'));
});

// ===========================
// Start Server
// ===========================
// ===========================
// Initialize & Start
// ===========================
async function startup() {
  // Initialize persistent PowerShell helper for input & media
  await input.init();
  // Cache static system info
  await monitor.initStaticInfo();

  server.listen(config.PORT, config.HOST, () => {
    console.log('');
    console.log('╔══════════════════════════════════════════════════╗');
    console.log('║           🎮 PC COMMANDER SERVER                ║');
    console.log('╠══════════════════════════════════════════════════╣');
    console.log(`║  Local:   http://localhost:${config.PORT}               ║`);
    console.log(`║  Network: http://${config.LOCAL_IP}:${config.PORT}          ║`);
    console.log('║                                                  ║');
    console.log(`║  PIN: ${config.PIN}                                     ║`);
    console.log('║                                                  ║');
    console.log('║  Open the Network URL on your iPad in Safari     ║');
    console.log('║  to start controlling this PC!                   ║');
    console.log('╚══════════════════════════════════════════════════╝');
    console.log('');
  });
}

startup().catch(err => {
  console.error('Startup failed:', err);
  process.exit(1);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\nShutting down...');
  input.stop();
  process.exit(0);
});
