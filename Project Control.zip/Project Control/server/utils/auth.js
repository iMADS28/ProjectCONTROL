// PC Commander - Authentication Module
const jwt = require('jsonwebtoken');
const config = require('../config');

const authState = {
  failedAttempts: 0,
  lockoutUntil: null,
};

function verifyPin(pin) {
  // Check lockout
  if (authState.lockoutUntil && Date.now() < authState.lockoutUntil) {
    const remaining = Math.ceil((authState.lockoutUntil - Date.now()) / 1000);
    return { success: false, error: `Too many attempts. Try again in ${remaining}s`, locked: true };
  }

  // Reset lockout if expired
  if (authState.lockoutUntil && Date.now() >= authState.lockoutUntil) {
    authState.failedAttempts = 0;
    authState.lockoutUntil = null;
  }

  if (pin === config.PIN) {
    authState.failedAttempts = 0;
    const token = jwt.sign({ authenticated: true }, config.JWT_SECRET, { expiresIn: config.SESSION_EXPIRY });
    return { success: true, token };
  } else {
    authState.failedAttempts++;
    if (authState.failedAttempts >= config.MAX_AUTH_ATTEMPTS) {
      authState.lockoutUntil = Date.now() + config.LOCKOUT_DURATION;
      return { success: false, error: 'Too many failed attempts. Locked out for 5 minutes.', locked: true };
    }
    return { success: false, error: `Invalid PIN. ${config.MAX_AUTH_ATTEMPTS - authState.failedAttempts} attempts remaining.` };
  }
}

function verifyToken(token) {
  try {
    const decoded = jwt.verify(token, config.JWT_SECRET);
    return { valid: true, decoded };
  } catch (err) {
    return { valid: false, error: 'Invalid or expired token' };
  }
}

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  const token = authHeader.split(' ')[1];
  const result = verifyToken(token);
  if (!result.valid) {
    return res.status(401).json({ error: result.error });
  }
  next();
}

module.exports = { verifyPin, verifyToken, authMiddleware };
