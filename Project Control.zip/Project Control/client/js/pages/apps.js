// PC Commander - Apps & Processes Page
const AppsPage = {
  initialized: false,
  appsList: [],
  processList: [],

  init() {
    if (this.initialized) return;
    this.initialized = true;
    this.loadApps();
  },

  switchTab(tab) {
    document.querySelectorAll('#page-apps .tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('#page-apps .tab-content').forEach(tc => tc.classList.remove('active'));
    document.getElementById(`tab-${tab}`).classList.add('active');
    event.target.classList.add('active');

    if (tab === 'processes') {
      this.loadProcesses();
    }
  },

  // ---- App Launcher ----
  async loadApps() {
    try {
      const apps = await Connection.api('/api/apps');
      this.appsList = apps || [];
      this.renderApps(this.appsList);
    } catch (err) {
      document.getElementById('app-grid').innerHTML =
        '<p style="color:var(--text-tertiary); padding:20px; text-align:center;">Failed to load apps</p>';
    }
  },

  renderApps(apps) {
    const grid = document.getElementById('app-grid');
    if (apps.length === 0) {
      grid.innerHTML = '<p style="color:var(--text-tertiary); padding:20px; text-align:center;">No apps found</p>';
      return;
    }

    grid.innerHTML = apps.slice(0, 80).map(app => {
      const name = app.Name || 'Unknown';
      const icon = this.getAppIcon(name);
      return `
        <div class="app-item" onclick="AppsPage.launchApp('${(app.Target || app.Path || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'")}')">
          <span class="icon">${icon}</span>
          <span class="name" title="${name}">${name}</span>
        </div>
      `;
    }).join('');
  },

  getAppIcon(name) {
    const n = name.toLowerCase();
    if (n.includes('chrome')) return '🌐';
    if (n.includes('firefox')) return '🦊';
    if (n.includes('edge')) return '🔵';
    if (n.includes('code') || n.includes('visual studio')) return '💻';
    if (n.includes('word')) return '📝';
    if (n.includes('excel')) return '📊';
    if (n.includes('powerpoint')) return '📽️';
    if (n.includes('outlook')) return '📧';
    if (n.includes('teams')) return '👥';
    if (n.includes('discord')) return '💬';
    if (n.includes('spotify')) return '🎵';
    if (n.includes('steam')) return '🎮';
    if (n.includes('notepad')) return '📒';
    if (n.includes('paint')) return '🎨';
    if (n.includes('calculator')) return '🔢';
    if (n.includes('terminal') || n.includes('powershell') || n.includes('cmd')) return '⬛';
    if (n.includes('explorer') || n.includes('file')) return '📁';
    if (n.includes('setting')) return '⚙️';
    if (n.includes('store')) return '🛒';
    if (n.includes('photo')) return '📷';
    if (n.includes('video') || n.includes('vlc') || n.includes('media')) return '🎬';
    if (n.includes('obs')) return '🎥';
    if (n.includes('zoom')) return '📹';
    if (n.includes('slack')) return '💼';
    if (n.includes('skype')) return '📞';
    return '📦';
  },

  filterApps(query) {
    const filtered = this.appsList.filter(app =>
      (app.Name || '').toLowerCase().includes(query.toLowerCase())
    );
    this.renderApps(filtered);
  },

  async launchApp(target) {
    if (!target) return;
    try {
      const result = await Connection.api('/api/apps/launch', {
        method: 'POST',
        body: JSON.stringify({ target }),
      });
      if (result.success) {
        Toast.show(result.message, 'success');
      } else {
        Toast.show(result.error || 'Failed to launch', 'error');
      }
    } catch (err) {
      Toast.show('Launch failed: ' + err.message, 'error');
    }
  },

  // ---- Processes ----
  async loadProcesses() {
    try {
      const processes = await Connection.api('/api/processes');
      this.processList = processes || [];
      this.renderProcesses(this.processList);
    } catch (err) {
      document.getElementById('process-list').innerHTML =
        '<p style="color:var(--text-tertiary); padding:20px; text-align:center;">Failed to load processes</p>';
    }
  },

  renderProcesses(processes) {
    const list = document.getElementById('process-list');
    if (processes.length === 0) {
      list.innerHTML = '<p style="color:var(--text-tertiary); padding:20px; text-align:center;">No processes found</p>';
      return;
    }

    list.innerHTML = processes.map(p => `
      <div class="process-item">
        <span class="process-name">${p.ProcessName || p.name || 'Unknown'}</span>
        <span class="process-stat">CPU: ${(p.CPU || p.cpu || 0).toFixed(1)}%</span>
        <span class="process-stat">${(p.MemoryMB || p.memRss || 0).toFixed ? (p.MemoryMB || 0).toFixed(0) : 0} MB</span>
        <button class="process-kill" onclick="AppsPage.killProcess(${p.Id || p.pid})" title="Kill process">✕</button>
      </div>
    `).join('');
  },

  filterProcesses(query) {
    const filtered = this.processList.filter(p =>
      (p.ProcessName || p.name || '').toLowerCase().includes(query.toLowerCase())
    );
    this.renderProcesses(filtered);
  },

  async refreshProcesses() {
    document.getElementById('process-list').innerHTML =
      '<div class="loading-overlay"><div class="spinner"></div> Refreshing...</div>';
    await this.loadProcesses();
    Toast.show('Processes refreshed', 'info');
  },

  async killProcess(pid) {
    Modal.confirm('Kill Process', `Are you sure you want to terminate process ${pid}?`, async () => {
      try {
        const result = await Connection.api(`/api/processes/${pid}`, { method: 'DELETE' });
        if (result.success) {
          Toast.show(result.message, 'success');
          this.loadProcesses();
        } else {
          Toast.show(result.error || 'Failed to kill process', 'error');
        }
      } catch (err) {
        Toast.show('Kill failed: ' + err.message, 'error');
      }
    });
  },
};
