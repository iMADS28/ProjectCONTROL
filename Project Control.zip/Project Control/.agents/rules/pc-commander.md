# PC Commander — Project Context

## What This Project Is
PC Commander is a full-featured remote desktop control app. It runs a Node.js server on a Windows PC and provides a web-based PWA client that can be accessed from any device (iPad, Android phone, laptop) via a browser.

## Project Location
- **Workspace**: `c:\Users\Christian\Documents\Project Control`
- **Server**: `server/` — Node.js + Express + WebSocket
- **Client**: `client/` — HTML/CSS/JS PWA (dark glassmorphic UI)

## Architecture
- **Server** (`server/server.js`): Express REST API + WebSocket for real-time communication
- **Client** (`client/index.html`): Single-page PWA with bottom tab navigation
- **Authentication**: PIN-based (default: `1234`) + JWT session tokens
- **Input System**: Uses a **persistent PowerShell process** with pre-compiled C# for instant keyboard/mouse/hotkey simulation (do NOT revert to exec-per-command approach — that caused 100% CPU)

## Key Files
### Server Modules (`server/modules/`)
| Module | Purpose |
|--------|---------|
| `input.js` | Persistent PS helper for keyboard, mouse, hotkeys |
| `media.js` | Volume control (loudness pkg) + media keys (via input.js PS helper) |
| `monitor.js` | System stats via systeminformation (cached static data, 5s interval) |
| `power.js` | Shutdown, restart, sleep, hibernate, lock, WOL |
| `apps.js` | App launcher + process manager |
| `screenshot.js` | Desktop screenshot capture |
| `files.js` | File browser & transfer |
| `clipboard.js` | Clipboard sync via PowerShell |
| `alerts.js` | Threshold-based system alerts |

### Config (`server/config.js`)
- PORT: 3300
- PIN: 1234
- MONITOR_INTERVAL: 5000ms
- WOL_MAC: needs to be set per machine

### Client Pages (`client/js/pages/`)
Dashboard, Power, Media, Input (keyboard/trackpad/hotkeys), Apps, Files, More (screenshot/clipboard/settings)

## Critical Performance Notes
- **NEVER** spawn a new PowerShell process per input command — this caused 100% CPU
- Input module uses ONE persistent `powershell.exe` that stays alive and accepts commands via stdin
- Monitor interval is 5 seconds — do not reduce below 3s
- `si.cpu()` is cached at startup (static data), not polled every cycle
- Mouse moves are throttled to max 1 per 30ms in server.js
- `si.processes()` is only fetched on-demand via REST, NOT in the polling loop

## How to Run
```bash
cd "c:\Users\Christian\Documents\Project Control\server"
npm start
```
Then open `http://<PC-IP>:3300` on any device.

## Planned Features (Not Yet Built)
- Multi-device switcher (control multiple PCs from one app)
- Internet access via localtunnel/ngrok
- Auto-start as Windows service
- Live screen streaming
