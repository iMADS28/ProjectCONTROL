// PC Commander - Gauge Component
const Gauge = {
  create(id, label, color1, color2) {
    const circumference = 2 * Math.PI * 45;
    return `
      <div class="gauge-card" id="gauge-${id}">
        <div class="gauge-container">
          <svg class="gauge-svg" viewBox="0 0 100 100">
            <circle class="gauge-bg" cx="50" cy="50" r="45" />
            <circle class="gauge-fill" cx="50" cy="50" r="45"
              stroke="url(#gradient-${id})"
              stroke-dasharray="${circumference}"
              stroke-dashoffset="${circumference}"
              id="gauge-fill-${id}" />
            <defs>
              <linearGradient id="gradient-${id}" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:${color1}" />
                <stop offset="100%" style="stop-color:${color2}" />
              </linearGradient>
            </defs>
          </svg>
          <div class="gauge-value">
            <span class="gauge-percent" id="gauge-value-${id}">0</span>
            <span class="gauge-unit" id="gauge-unit-${id}">%</span>
          </div>
        </div>
        <div class="gauge-label">${label}</div>
        <div class="gauge-detail" id="gauge-detail-${id}"></div>
      </div>
    `;
  },

  update(id, value, detail = '', unit = '%') {
    const circumference = 2 * Math.PI * 45;
    const fillEl = document.getElementById(`gauge-fill-${id}`);
    const valueEl = document.getElementById(`gauge-value-${id}`);
    const unitEl = document.getElementById(`gauge-unit-${id}`);
    const detailEl = document.getElementById(`gauge-detail-${id}`);

    if (fillEl) {
      const offset = circumference - (value / 100) * circumference;
      fillEl.setAttribute('stroke-dashoffset', offset);
    }
    if (valueEl) {
      this.animateValue(valueEl, parseFloat(valueEl.textContent) || 0, value, 600);
    }
    if (unitEl) unitEl.textContent = unit;
    if (detailEl) detailEl.textContent = detail;
  },

  animateValue(el, start, end, duration) {
    const startTime = performance.now();
    const diff = end - start;

    function step(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
      const current = start + diff * eased;
      el.textContent = current < 10 ? current.toFixed(1) : Math.round(current);
      if (progress < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  },
};
