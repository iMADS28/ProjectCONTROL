// PC Commander - Remote Input Module (Keyboard, Mouse, Hotkeys)
// Uses a PERSISTENT PowerShell process with pre-compiled C# for instant input
const { spawn } = require('child_process');
const path = require('path');

// ============================================
// Persistent PowerShell Process Manager
// ============================================
class PSHelper {
  constructor() {
    this.process = null;
    this.ready = false;
    this.queue = [];
    this.responseCallback = null;
    this.buffer = '';
  }

  start() {
    return new Promise((resolve, reject) => {
      this.process = spawn('powershell.exe', [
        '-NoProfile', '-NoLogo', '-ExecutionPolicy', 'Bypass',
        '-Command', '-'  // Read commands from stdin
      ], {
        stdio: ['pipe', 'pipe', 'pipe'],
        windowsHide: true,
      });

      this.process.stdout.on('data', (data) => {
        this.buffer += data.toString();
        // Check for our response delimiter
        const lines = this.buffer.split('\n');
        for (let i = 0; i < lines.length - 1; i++) {
          const line = lines[i].trim();
          if (line === '<<READY>>') {
            this.ready = true;
            resolve();
          } else if (line === '<<OK>>') {
            if (this.responseCallback) {
              this.responseCallback({ success: true });
              this.responseCallback = null;
            }
            this.processQueue();
          } else if (line.startsWith('<<RESULT:')) {
            const result = line.replace('<<RESULT:', '').replace('>>', '');
            if (this.responseCallback) {
              this.responseCallback({ success: true, data: result });
              this.responseCallback = null;
            }
            this.processQueue();
          } else if (line.startsWith('<<ERROR:')) {
            const error = line.replace('<<ERROR:', '').replace('>>', '');
            if (this.responseCallback) {
              this.responseCallback({ success: false, error });
              this.responseCallback = null;
            }
            this.processQueue();
          }
        }
        this.buffer = lines[lines.length - 1];
      });

      this.process.stderr.on('data', (data) => {
        // Ignore non-critical stderr (PS warnings)
        const msg = data.toString().trim();
        if (msg && !msg.includes('ProgressPreference')) {
          console.error('[PS Helper stderr]:', msg);
        }
      });

      this.process.on('close', (code) => {
        console.log('[PS Helper] Process exited with code:', code);
        this.ready = false;
        // Auto-restart after 1 second
        setTimeout(() => this.start(), 1000);
      });

      this.process.on('error', (err) => {
        console.error('[PS Helper] Process error:', err);
        reject(err);
      });

      // Send initialization script
      this.sendRaw(INIT_SCRIPT);
    });
  }

  sendRaw(script) {
    if (this.process && this.process.stdin.writable) {
      this.process.stdin.write(script + '\n');
    }
  }

  exec(command) {
    return new Promise((resolve) => {
      this.queue.push({ command, resolve });
      if (!this.responseCallback) {
        this.processQueue();
      }
    });
  }

  processQueue() {
    if (this.queue.length === 0) return;
    const { command, resolve } = this.queue.shift();
    this.responseCallback = resolve;
    this.sendRaw(command);
  }

  stop() {
    if (this.process) {
      this.process.stdin.end();
      this.process.kill();
      this.process = null;
      this.ready = false;
    }
  }
}

// ============================================
// PowerShell Initialization Script
// Compiles C# ONCE, then loops reading commands from stdin
// ============================================
const INIT_SCRIPT = `
$ProgressPreference = 'SilentlyContinue'

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
using System.Threading;

public class InputSim {
    [DllImport("user32.dll")] static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
    [DllImport("user32.dll")] static extern void mouse_event(uint dwFlags, int dx, int dy, uint dwData, UIntPtr dwExtraInfo);
    [DllImport("user32.dll")] static extern bool GetCursorPos(out POINT lpPoint);

    [StructLayout(LayoutKind.Sequential)]
    public struct POINT { public int X; public int Y; }

    public static void KeyDown(byte vk) { keybd_event(vk, 0, 0, UIntPtr.Zero); }
    public static void KeyUp(byte vk) { keybd_event(vk, 0, 2, UIntPtr.Zero); }
    public static void KeyPress(byte vk) { KeyDown(vk); Thread.Sleep(10); KeyUp(vk); }

    public static void MouseMove(int dx, int dy) { mouse_event(0x0001, dx, dy, 0, UIntPtr.Zero); }
    public static void LeftClick() { mouse_event(0x0002, 0, 0, 0, UIntPtr.Zero); mouse_event(0x0004, 0, 0, 0, UIntPtr.Zero); }
    public static void RightClick() { mouse_event(0x0008, 0, 0, 0, UIntPtr.Zero); mouse_event(0x0010, 0, 0, 0, UIntPtr.Zero); }
    public static void DoubleClick() { LeftClick(); Thread.Sleep(50); LeftClick(); }
    public static void Scroll(int d) { mouse_event(0x0800, 0, 0, (uint)(d * 120), UIntPtr.Zero); }
    public static string GetPos() { POINT p; GetCursorPos(out p); return p.X + "," + p.Y; }
}
"@

Add-Type -AssemblyName System.Windows.Forms

Write-Output "<<READY>>"

# Command loop
while ($true) {
    $line = [Console]::ReadLine()
    if ($line -eq $null) { break }
    $line = $line.Trim()
    if ($line -eq "") { continue }

    try {
        $parts = $line -split ' ', 2
        $cmd = $parts[0]
        $args_str = if ($parts.Length -gt 1) { $parts[1] } else { "" }

        switch ($cmd) {
            "KEY" {
                $vk = [byte]$args_str
                [InputSim]::KeyPress($vk)
                Write-Output "<<OK>>"
            }
            "KEYDOWN" {
                $vk = [byte]$args_str
                [InputSim]::KeyDown($vk)
                Write-Output "<<OK>>"
            }
            "KEYUP" {
                $vk = [byte]$args_str
                [InputSim]::KeyUp($vk)
                Write-Output "<<OK>>"
            }
            "HOTKEY" {
                $vks = $args_str -split ','
                foreach ($v in $vks) { [InputSim]::KeyDown([byte]$v) }
                Start-Sleep -Milliseconds 50
                [array]::Reverse($vks)
                foreach ($v in $vks) { [InputSim]::KeyUp([byte]$v) }
                Write-Output "<<OK>>"
            }
            "MOUSE" {
                $xy = $args_str -split ','
                [InputSim]::MouseMove([int]$xy[0], [int]$xy[1])
                Write-Output "<<OK>>"
            }
            "CLICK" {
                switch ($args_str) {
                    "left" { [InputSim]::LeftClick() }
                    "right" { [InputSim]::RightClick() }
                    "double" { [InputSim]::DoubleClick() }
                }
                Write-Output "<<OK>>"
            }
            "SCROLL" {
                [InputSim]::Scroll([int]$args_str)
                Write-Output "<<OK>>"
            }
            "MOUSEPOS" {
                $pos = [InputSim]::GetPos()
                Write-Output "<<RESULT:$pos>>"
            }
            "TYPE" {
                [System.Windows.Forms.SendKeys]::SendWait($args_str)
                Write-Output "<<OK>>"
            }
            "MEDIAKEY" {
                $vk = [byte]$args_str
                [InputSim]::KeyPress($vk)
                Write-Output "<<OK>>"
            }
            "PING" {
                Write-Output "<<OK>>"
            }
            default {
                Write-Output "<<ERROR:Unknown command: $cmd>>"
            }
        }
    } catch {
        Write-Output "<<ERROR:$($_.Exception.Message)>>"
    }
}
`;

// ============================================
// Virtual Key Code Map
// ============================================
const VK_CODES = {
  'backspace': 0x08, 'tab': 0x09, 'enter': 0x0D, 'shift': 0x10,
  'ctrl': 0x11, 'alt': 0x12, 'pause': 0x13, 'capslock': 0x14,
  'escape': 0x1B, 'space': 0x20, 'pageup': 0x21, 'pagedown': 0x22,
  'end': 0x23, 'home': 0x24, 'left': 0x25, 'up': 0x26,
  'right': 0x27, 'down': 0x28, 'printscreen': 0x2C, 'insert': 0x2D,
  'delete': 0x2E, 'win': 0x5B, 'f1': 0x70, 'f2': 0x71,
  'f3': 0x72, 'f4': 0x73, 'f5': 0x74, 'f6': 0x75,
  'f7': 0x76, 'f8': 0x77, 'f9': 0x78, 'f10': 0x79,
  'f11': 0x7A, 'f12': 0x7B, 'numlock': 0x90, 'scrolllock': 0x91,
};

function getVK(key) {
  if (VK_CODES[key.toLowerCase()]) return VK_CODES[key.toLowerCase()];
  if (key.length === 1) return key.toUpperCase().charCodeAt(0);
  return null;
}

// ============================================
// Singleton PS Helper instance
// ============================================
const psHelper = new PSHelper();

// ============================================
// Input Module (Public API)
// ============================================
const input = {
  // Initialize — call this once at server start
  async init() {
    try {
      await psHelper.start();
      console.log('[Input] Persistent PowerShell helper started');
    } catch (err) {
      console.error('[Input] Failed to start PS helper:', err.message);
    }
  },

  // Send a single key press
  async keyPress(key) {
    const vk = getVK(key);
    if (!vk) return { success: false, error: `Unknown key: ${key}` };
    const result = await psHelper.exec(`KEY ${vk}`);
    return { ...result, key };
  },

  // Send a key combination (e.g., ['ctrl', 'c'])
  async hotkey(keys) {
    const vks = keys.map(k => getVK(k)).filter(Boolean);
    if (vks.length === 0) return { success: false, error: 'No valid keys' };
    const result = await psHelper.exec(`HOTKEY ${vks.join(',')}`);
    return { ...result, keys };
  },

  // Type a string of text
  async typeText(text) {
    // Escape special SendKeys characters
    const escaped = text
      .replace(/\+/g, '{+}')
      .replace(/\^/g, '{^}')
      .replace(/~/g, '{~}')
      .replace(/%/g, '{%}')
      .replace(/\(/g, '{(}')
      .replace(/\)/g, '{)}')
      .replace(/\{/g, '{{}')
      .replace(/\}/g, '{}}');

    const result = await psHelper.exec(`TYPE ${escaped}`);
    return { ...result, length: text.length };
  },

  // Mouse move (relative)
  async mouseMove(dx, dy) {
    const result = await psHelper.exec(`MOUSE ${dx},${dy}`);
    return { ...result, dx, dy };
  },

  // Mouse click
  async mouseClick(button = 'left') {
    const result = await psHelper.exec(`CLICK ${button}`);
    return { ...result, button };
  },

  // Mouse scroll
  async mouseScroll(amount) {
    const result = await psHelper.exec(`SCROLL ${amount}`);
    return { ...result, amount };
  },

  // Get mouse position
  async getMousePosition() {
    const result = await psHelper.exec('MOUSEPOS');
    if (result.success && result.data) {
      const [x, y] = result.data.split(',').map(Number);
      return { x, y };
    }
    return { x: 0, y: 0 };
  },

  // Send media key
  async sendMediaKey(vkCode) {
    const result = await psHelper.exec(`MEDIAKEY ${vkCode}`);
    return result;
  },

  // Shutdown helper
  stop() {
    psHelper.stop();
  },

  // Predefined hotkeys
  presets: {
    'copy': ['ctrl', 'c'],
    'paste': ['ctrl', 'v'],
    'cut': ['ctrl', 'x'],
    'undo': ['ctrl', 'z'],
    'redo': ['ctrl', 'y'],
    'select_all': ['ctrl', 'a'],
    'save': ['ctrl', 's'],
    'find': ['ctrl', 'f'],
    'close_window': ['alt', 'f4'],
    'switch_window': ['alt', 'tab'],
    'task_manager': ['ctrl', 'shift', 'escape'],
    'desktop': ['win', 'd'],
    'lock': ['win', 'l'],
    'explorer': ['win', 'e'],
    'run': ['win', 'r'],
    'screenshot': ['win', 'shift', 's'],
    'settings': ['win', 'i'],
    'minimize_all': ['win', 'm'],
    'emoji': ['win', '.'],
    'clipboard_history': ['win', 'v'],
  },
};

module.exports = input;
