// PC Commander - Dashboard Page
const Dashboard = {
  initialized: false,

  init() {
    if (this.initialized) return;
    this.initialized = true;

    // Create gauge grid
    const grid = document.getElementById('gauge-grid');
    grid.innerHTML =
      Gauge.create('cpu', 'CPU', '#6366f1', '#a855f7') +
      Gauge.create('ram', 'RAM', '#8b5cf6', '#ec4899') +
      Gauge.create('gpu', 'GPU', '#06b6d4', '#3b82f6') +
      Gauge.create('temp', 'Temp', '#f97316', '#ef4444');

    // Listen for system stats
    Connection.on('system_stats', (msg) => this.updateStats(msg.stats));
  },

  updateStats(stats) {
    if (!stats) return;

    // CPU Gauge
    Gauge.update('cpu', stats.cpu.usage || 0,
      `${stats.cpu.cores} cores • ${stats.cpu.speed} GHz`);

    // RAM Gauge
    const ramUsedGB = (stats.memory.used / (1024 ** 3)).toFixed(1);
    const ramTotalGB = (stats.memory.total / (1024 ** 3)).toFixed(1);
    Gauge.update('ram', stats.memory.usage || 0,
      `${ramUsedGB} / ${ramTotalGB} GB`);

    // GPU Gauge
    if (stats.gpu && stats.gpu.length > 0) {
      const gpu = stats.gpu[0];
      Gauge.update('gpu', gpu.utilizationGpu || 0,
        gpu.model || 'GPU');
    } else {
      Gauge.update('gpu', 0, 'No GPU data');
    }

    // Temperature Gauge
    const cpuTemp = stats.cpu.temperature || 0;
    const gpuTemp = stats.gpu && stats.gpu.length > 0 ? (stats.gpu[0].temperatureGpu || 0) : 0;
    const maxTemp = Math.max(cpuTemp, gpuTemp);
    Gauge.update('temp', Math.min(maxTemp, 100),
      cpuTemp ? `CPU: ${cpuTemp}°C` : 'N/A', '°C');

    // System Info
    this.updateSystemInfo(stats);
    this.updateDiskInfo(stats.disks);
    this.updateNetworkInfo(stats.network);
  },

  updateSystemInfo(stats) {
    const el = document.getElementById('system-info');
    if (!el) return;

    const uptime = this.formatUptime(stats.uptime);
    el.innerHTML = `
      <div class="info-row">
        <span class="info-label">Hostname</span>
        <span class="info-value">${stats.hostname}</span>
      </div>
      <div class="info-row">
        <span class="info-label">CPU</span>
        <span class="info-value">${stats.cpu.model}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Platform</span>
        <span class="info-value">${stats.platform} (${stats.arch})</span>
      </div>
      <div class="info-row">
        <span class="info-label">Uptime</span>
        <span class="info-value">${uptime}</span>
      </div>
    `;
  },

  updateDiskInfo(disks) {
    const el = document.getElementById('disk-info');
    if (!el || !disks) return;

    el.innerHTML = disks.map(disk => {
      const usedGB = (disk.used / (1024 ** 3)).toFixed(1);
      const totalGB = (disk.size / (1024 ** 3)).toFixed(1);
      const barClass = disk.usage > 90 ? 'danger' : disk.usage > 75 ? 'warning' : '';
      return `
        <div class="bar-container">
          <div class="bar-label">
            <span>${disk.mount}</span>
            <span>${usedGB} / ${totalGB} GB (${disk.usage.toFixed(1)}%)</span>
          </div>
          <div class="bar-track">
            <div class="bar-fill ${barClass}" style="width: ${disk.usage}%"></div>
          </div>
        </div>
      `;
    }).join('');
  },

  updateNetworkInfo(network) {
    const el = document.getElementById('network-info');
    if (!el || !network) return;

    el.innerHTML = network.filter(n => n.rxSec > 0 || n.txSec > 0 || n.rxTotal > 0).slice(0, 3).map(net => `
      <div class="info-row">
        <span class="info-label">${net.iface}</span>
        <span class="info-value">↓ ${this.formatSpeed(net.rxSec)} &nbsp; ↑ ${this.formatSpeed(net.txSec)}</span>
      </div>
    `).join('') || '<div class="info-row"><span class="info-label">No active interfaces</span></div>';
  },

  formatUptime(seconds) {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const parts = [];
    if (days > 0) parts.push(`${days}d`);
    if (hours > 0) parts.push(`${hours}h`);
    parts.push(`${mins}m`);
    return parts.join(' ');
  },

  formatSpeed(bytesPerSec) {
    if (!bytesPerSec || bytesPerSec < 0) return '0 B/s';
    if (bytesPerSec < 1024) return `${bytesPerSec.toFixed(0)} B/s`;
    if (bytesPerSec < 1024 * 1024) return `${(bytesPerSec / 1024).toFixed(1)} KB/s`;
    return `${(bytesPerSec / (1024 * 1024)).toFixed(1)} MB/s`;
  },
};
