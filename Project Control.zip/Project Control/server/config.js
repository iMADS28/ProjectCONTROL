// PC Commander - Server Configuration
const os = require('os');
const path = require('path');

// Get local IP address
function getLocalIP() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return '127.0.0.1';
}

module.exports = {
  // Server settings
  PORT: 3300,
  HOST: '0.0.0.0',
  LOCAL_IP: getLocalIP(),

  // Authentication
  PIN: '1234', // Change this to your desired PIN
  JWT_SECRET: 'pc-commander-secret-' + Date.now(),
  SESSION_EXPIRY: '24h',
  MAX_AUTH_ATTEMPTS: 5,
  LOCKOUT_DURATION: 5 * 60 * 1000, // 5 minutes

  // Monitoring
  MONITOR_INTERVAL: 5000, // Send stats every 5 seconds

  // File browser
  ALLOWED_ROOTS: [
    os.homedir(),
    'C:\\',
    'D:\\',
  ],

  // Screenshots
  SCREENSHOT_DIR: path.join(os.tmpdir(), 'pc-commander-screenshots'),

  // Upload directory
  UPLOAD_DIR: path.join(os.homedir(), 'Downloads', 'PC-Commander-Uploads'),

  // Alert thresholds (default)
  ALERTS: {
    CPU_THRESHOLD: 90,
    RAM_THRESHOLD: 90,
    DISK_THRESHOLD: 90,
    TEMP_THRESHOLD: 85,
  },

  // Wake-on-LAN (set your PC's MAC address here for remote WOL)
  WOL_MAC: 'FF:FF:FF:FF:FF:FF',

  // Client path
  CLIENT_PATH: path.join(__dirname, '..', 'client'),
};
