// PC Commander - System Alerts Module
const config = require('../config');

class AlertManager {
  constructor() {
    this.thresholds = { ...config.ALERTS };
    this.activeAlerts = [];
    this.alertHistory = [];
    this.listeners = [];
  }

  // Check system stats against thresholds
  checkStats(stats) {
    const newAlerts = [];

    // CPU check
    if (stats.cpu && stats.cpu.usage > this.thresholds.CPU_THRESHOLD) {
      newAlerts.push({
        type: 'cpu',
        severity: 'warning',
        message: `CPU usage is high: ${stats.cpu.usage.toFixed(1)}%`,
        value: stats.cpu.usage,
        threshold: this.thresholds.CPU_THRESHOLD,
        timestamp: Date.now(),
      });
    }

    // Memory check
    if (stats.memory && stats.memory.usage > this.thresholds.RAM_THRESHOLD) {
      newAlerts.push({
        type: 'memory',
        severity: 'warning',
        message: `RAM usage is high: ${stats.memory.usage.toFixed(1)}%`,
        value: stats.memory.usage,
        threshold: this.thresholds.RAM_THRESHOLD,
        timestamp: Date.now(),
      });
    }

    // Disk check
    if (stats.disks) {
      stats.disks.forEach(disk => {
        if (disk.usage > this.thresholds.DISK_THRESHOLD) {
          newAlerts.push({
            type: 'disk',
            severity: 'critical',
            message: `Disk ${disk.mount} is almost full: ${disk.usage.toFixed(1)}%`,
            value: disk.usage,
            threshold: this.thresholds.DISK_THRESHOLD,
            timestamp: Date.now(),
          });
        }
      });
    }

    // Temperature check
    if (stats.cpu && stats.cpu.temperature && stats.cpu.temperature > this.thresholds.TEMP_THRESHOLD) {
      newAlerts.push({
        type: 'temperature',
        severity: 'critical',
        message: `CPU temperature is high: ${stats.cpu.temperature}°C`,
        value: stats.cpu.temperature,
        threshold: this.thresholds.TEMP_THRESHOLD,
        timestamp: Date.now(),
      });
    }

    // GPU temperature check
    if (stats.gpu) {
      stats.gpu.forEach(gpu => {
        if (gpu.temperatureGpu && gpu.temperatureGpu > this.thresholds.TEMP_THRESHOLD) {
          newAlerts.push({
            type: 'gpu_temp',
            severity: 'critical',
            message: `GPU temperature is high: ${gpu.temperatureGpu}°C (${gpu.model})`,
            value: gpu.temperatureGpu,
            threshold: this.thresholds.TEMP_THRESHOLD,
            timestamp: Date.now(),
          });
        }
      });
    }

    // Update active alerts
    this.activeAlerts = newAlerts;

    // Add to history (avoid duplicates within 30 seconds)
    newAlerts.forEach(alert => {
      const recent = this.alertHistory.find(h =>
        h.type === alert.type && (Date.now() - h.timestamp) < 30000
      );
      if (!recent) {
        this.alertHistory.push(alert);
        // Keep history limited
        if (this.alertHistory.length > 100) {
          this.alertHistory = this.alertHistory.slice(-50);
        }
        // Notify listeners
        this.listeners.forEach(fn => fn(alert));
      }
    });

    return newAlerts;
  }

  // Update thresholds
  updateThresholds(newThresholds) {
    Object.assign(this.thresholds, newThresholds);
    return this.thresholds;
  }

  // Add alert listener
  onAlert(fn) {
    this.listeners.push(fn);
  }

  // Get alert history
  getHistory() {
    return this.alertHistory.slice(-50).reverse();
  }

  // Clear alert history
  clearHistory() {
    this.alertHistory = [];
    return { success: true, message: 'Alert history cleared.' };
  }
}

module.exports = new AlertManager();
