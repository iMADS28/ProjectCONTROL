// PC Commander - App & Process Management Module
const { exec } = require('child_process');
const path = require('path');

const apps = {
  // Get list of installed apps (from Start Menu shortcuts)
  getInstalledApps() {
    return new Promise((resolve, reject) => {
      const psScript = `
        $apps = @()
        $paths = @(
          "$env:ProgramData\\Microsoft\\Windows\\Start Menu\\Programs",
          "$env:APPDATA\\Microsoft\\Windows\\Start Menu\\Programs"
        )
        foreach ($p in $paths) {
          Get-ChildItem -Path $p -Recurse -Filter "*.lnk" -ErrorAction SilentlyContinue | ForEach-Object {
            $shell = New-Object -ComObject WScript.Shell
            $shortcut = $shell.CreateShortcut($_.FullName)
            $apps += [PSCustomObject]@{
              Name = $_.BaseName
              Target = $shortcut.TargetPath
              Icon = $shortcut.IconLocation
              Path = $_.FullName
            }
          }
        }
        $apps | Sort-Object Name -Unique | ConvertTo-Json -Depth 2
      `;
      exec(`powershell -NoProfile -Command "${psScript.replace(/\n/g, ' ')}"`, { maxBuffer: 1024 * 1024 * 5 }, (err, stdout) => {
        if (err) reject(err);
        else {
          try {
            const result = JSON.parse(stdout);
            resolve(Array.isArray(result) ? result : [result]);
          } catch (e) {
            resolve([]);
          }
        }
      });
    });
  },

  // Launch an application
  launchApp(target) {
    return new Promise((resolve, reject) => {
      // Sanitize path
      const sanitized = target.replace(/[;&|`$]/g, '');
      exec(`start "" "${sanitized}"`, { shell: true }, (err) => {
        if (err) reject(err);
        else resolve({ success: true, message: `Launched: ${path.basename(sanitized)}` });
      });
    });
  },

  // Get running processes
  getProcesses() {
    return new Promise((resolve, reject) => {
      const psScript = `Get-Process | Select-Object Id, ProcessName, CPU, @{Name='MemoryMB';Expression={[math]::Round($_.WorkingSet64/1MB,1)}}, MainWindowTitle | Sort-Object CPU -Descending | Select-Object -First 50 | ConvertTo-Json`;
      exec(`powershell -NoProfile -Command "${psScript}"`, { maxBuffer: 1024 * 1024 }, (err, stdout) => {
        if (err) reject(err);
        else {
          try {
            const result = JSON.parse(stdout);
            resolve(Array.isArray(result) ? result : [result]);
          } catch (e) {
            resolve([]);
          }
        }
      });
    });
  },

  // Kill a process by PID
  killProcess(pid) {
    return new Promise((resolve, reject) => {
      exec(`taskkill /PID ${parseInt(pid)} /F`, (err, stdout) => {
        if (err) reject(err);
        else resolve({ success: true, message: `Process ${pid} terminated.` });
      });
    });
  },

  // Open a URL in default browser
  openUrl(url) {
    return new Promise((resolve, reject) => {
      exec(`start "" "${url}"`, { shell: true }, (err) => {
        if (err) reject(err);
        else resolve({ success: true, message: `Opened: ${url}` });
      });
    });
  },
};

module.exports = apps;
