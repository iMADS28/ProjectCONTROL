// PC Commander - Clipboard Sync Module
const { exec } = require('child_process');

const clipboard = {
  // Read clipboard content using PowerShell
  read() {
    return new Promise((resolve, reject) => {
      exec('powershell -NoProfile -Command "Get-Clipboard"', { maxBuffer: 1024 * 1024 }, (err, stdout) => {
        if (err) reject(err);
        else resolve({ success: true, content: stdout.trimEnd() });
      });
    });
  },

  // Write to clipboard using PowerShell
  write(text) {
    return new Promise((resolve, reject) => {
      // Escape for PowerShell
      const escaped = text.replace(/'/g, "''");
      exec(`powershell -NoProfile -Command "Set-Clipboard -Value '${escaped}'"`, (err) => {
        if (err) reject(err);
        else resolve({ success: true, message: 'Clipboard updated.' });
      });
    });
  },

  // Clear clipboard
  clear() {
    return new Promise((resolve, reject) => {
      exec('powershell -NoProfile -Command "Set-Clipboard -Value $null"', (err) => {
        if (err) reject(err);
        else resolve({ success: true, message: 'Clipboard cleared.' });
      });
    });
  },
};

module.exports = clipboard;
