// PC Commander - File Browser & Transfer Module
const fs = require('fs');
const path = require('path');
const config = require('../config');

// Ensure upload directory exists
if (!fs.existsSync(config.UPLOAD_DIR)) {
  fs.mkdirSync(config.UPLOAD_DIR, { recursive: true });
}

const files = {
  // List directory contents
  listDirectory(dirPath) {
    try {
      // Security: check if path is within allowed roots
      const normalized = path.resolve(dirPath);
      const isAllowed = config.ALLOWED_ROOTS.some(root =>
        normalized.toLowerCase().startsWith(path.resolve(root).toLowerCase())
      );
      if (!isAllowed) {
        return { success: false, error: 'Access denied: path not in allowed roots' };
      }

      const items = fs.readdirSync(normalized, { withFileTypes: true });
      const result = items
        .map(item => {
          try {
            const fullPath = path.join(normalized, item.name);
            const stats = fs.statSync(fullPath);
            return {
              name: item.name,
              path: fullPath,
              isDirectory: item.isDirectory(),
              size: item.isDirectory() ? null : stats.size,
              modified: stats.mtime,
              created: stats.birthtime,
              extension: item.isDirectory() ? null : path.extname(item.name).toLowerCase(),
            };
          } catch (e) {
            return {
              name: item.name,
              path: path.join(normalized, item.name),
              isDirectory: item.isDirectory(),
              size: null,
              error: 'Access denied',
            };
          }
        })
        .sort((a, b) => {
          // Directories first, then by name
          if (a.isDirectory && !b.isDirectory) return -1;
          if (!a.isDirectory && b.isDirectory) return 1;
          return a.name.localeCompare(b.name);
        });

      return {
        success: true,
        path: normalized,
        parent: path.dirname(normalized),
        items: result,
      };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },

  // Get file info
  getFileInfo(filePath) {
    try {
      const normalized = path.resolve(filePath);
      const stats = fs.statSync(normalized);
      return {
        success: true,
        name: path.basename(normalized),
        path: normalized,
        size: stats.size,
        isDirectory: stats.isDirectory(),
        modified: stats.mtime,
        created: stats.birthtime,
        extension: path.extname(normalized).toLowerCase(),
      };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },

  // Delete file or empty directory
  deleteItem(itemPath) {
    try {
      const normalized = path.resolve(itemPath);
      const stats = fs.statSync(normalized);
      if (stats.isDirectory()) {
        fs.rmdirSync(normalized);
      } else {
        fs.unlinkSync(normalized);
      }
      return { success: true, message: `Deleted: ${path.basename(normalized)}` };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },

  // Create directory
  createDirectory(dirPath) {
    try {
      const normalized = path.resolve(dirPath);
      fs.mkdirSync(normalized, { recursive: true });
      return { success: true, message: `Created directory: ${path.basename(normalized)}` };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },

  // Rename file or directory
  renameItem(oldPath, newName) {
    try {
      const normalized = path.resolve(oldPath);
      const newPath = path.join(path.dirname(normalized), newName);
      fs.renameSync(normalized, newPath);
      return { success: true, message: `Renamed to: ${newName}` };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },

  // Get allowed roots for browsing
  getRoots() {
    return config.ALLOWED_ROOTS.map(root => ({
      path: root,
      name: root === require('os').homedir() ? 'Home' : root,
    }));
  },

  // Format file size
  formatSize(bytes) {
    if (bytes === null || bytes === undefined) return '';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    let size = bytes;
    while (size >= 1024 && i < units.length - 1) {
      size /= 1024;
      i++;
    }
    return `${size.toFixed(1)} ${units[i]}`;
  },
};

module.exports = files;
