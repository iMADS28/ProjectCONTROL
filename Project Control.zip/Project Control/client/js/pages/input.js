// PC Commander - Input Page (Keyboard, Trackpad, Hotkeys)
const InputPage = {
  initialized: false,
  trackpadActive: false,
  lastTouch: null,

  init() {
    if (this.initialized) return;
    this.initialized = true;

    this.setupKeyboardInput();
    this.setupTrackpad();
    this.setupHotkeys();
  },

  // Tab switching
  switchTab(tab) {
    document.querySelectorAll('#page-input .tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('#page-input .tab-content').forEach(tc => tc.classList.remove('active'));
    document.getElementById(`tab-${tab}`).classList.add('active');
    event.target.classList.add('active');
  },

  // ---- Keyboard ----
  setupKeyboardInput() {
    const input = document.getElementById('remote-text-input');
    if (!input) return;

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const text = input.value;
        if (text) {
          Connection.send({ type: 'type_text', text });
          Toast.show(`Typed: "${text.substring(0, 30)}${text.length > 30 ? '...' : ''}"`, 'success');
          input.value = '';
        }
        // Also send Enter key
        Connection.send({ type: 'key_press', key: 'enter' });
      }
    });
  },

  sendKey(key) {
    Connection.send({ type: 'key_press', key });
  },

  // ---- Trackpad ----
  setupTrackpad() {
    const pad = document.getElementById('trackpad-area');
    if (!pad) return;

    pad.addEventListener('touchstart', (e) => {
      e.preventDefault();
      this.trackpadActive = true;
      pad.classList.add('active');
      const touch = e.touches[0];
      this.lastTouch = { x: touch.clientX, y: touch.clientY };
    });

    pad.addEventListener('touchmove', (e) => {
      e.preventDefault();
      if (!this.trackpadActive || !this.lastTouch) return;

      const touch = e.touches[0];
      const dx = Math.round((touch.clientX - this.lastTouch.x) * 1.5);
      const dy = Math.round((touch.clientY - this.lastTouch.y) * 1.5);

      if (Math.abs(dx) > 0 || Math.abs(dy) > 0) {
        Connection.send({ type: 'mouse_move', dx, dy });
        this.lastTouch = { x: touch.clientX, y: touch.clientY };
      }
    });

    pad.addEventListener('touchend', (e) => {
      e.preventDefault();
      this.trackpadActive = false;
      pad.classList.remove('active');
      this.lastTouch = null;
    });

    // Mouse events for desktop testing
    let mouseDown = false;
    pad.addEventListener('mousedown', (e) => {
      mouseDown = true;
      pad.classList.add('active');
      this.lastTouch = { x: e.clientX, y: e.clientY };
    });

    pad.addEventListener('mousemove', (e) => {
      if (!mouseDown || !this.lastTouch) return;
      const dx = Math.round((e.clientX - this.lastTouch.x) * 1.5);
      const dy = Math.round((e.clientY - this.lastTouch.y) * 1.5);
      if (Math.abs(dx) > 0 || Math.abs(dy) > 0) {
        Connection.send({ type: 'mouse_move', dx, dy });
        this.lastTouch = { x: e.clientX, y: e.clientY };
      }
    });

    pad.addEventListener('mouseup', () => {
      mouseDown = false;
      pad.classList.remove('active');
      this.lastTouch = null;
    });

    pad.addEventListener('mouseleave', () => {
      mouseDown = false;
      pad.classList.remove('active');
    });
  },

  mouseClick(button) {
    Connection.send({ type: 'mouse_click', button });
    Toast.show(`${button} click`, 'info');
  },

  scroll(amount) {
    Connection.send({ type: 'mouse_scroll', amount });
  },

  // ---- Hotkeys ----
  setupHotkeys() {
    const grid = document.getElementById('hotkey-grid');
    if (!grid) return;

    const hotkeys = [
      { name: 'copy', icon: '📋', label: 'Copy', keys: 'Ctrl+C' },
      { name: 'paste', icon: '📌', label: 'Paste', keys: 'Ctrl+V' },
      { name: 'cut', icon: '✂️', label: 'Cut', keys: 'Ctrl+X' },
      { name: 'undo', icon: '↩️', label: 'Undo', keys: 'Ctrl+Z' },
      { name: 'redo', icon: '↪️', label: 'Redo', keys: 'Ctrl+Y' },
      { name: 'select_all', icon: '🔲', label: 'Select All', keys: 'Ctrl+A' },
      { name: 'save', icon: '💾', label: 'Save', keys: 'Ctrl+S' },
      { name: 'find', icon: '🔍', label: 'Find', keys: 'Ctrl+F' },
      { name: 'close_window', icon: '❌', label: 'Close', keys: 'Alt+F4' },
      { name: 'switch_window', icon: '🔀', label: 'Switch', keys: 'Alt+Tab' },
      { name: 'task_manager', icon: '📊', label: 'Task Mgr', keys: 'Ctrl+Shift+Esc' },
      { name: 'desktop', icon: '🖥️', label: 'Desktop', keys: 'Win+D' },
      { name: 'lock', icon: '🔒', label: 'Lock', keys: 'Win+L' },
      { name: 'explorer', icon: '📁', label: 'Explorer', keys: 'Win+E' },
      { name: 'run', icon: '▶️', label: 'Run', keys: 'Win+R' },
      { name: 'screenshot', icon: '📸', label: 'Snip', keys: 'Win+Shift+S' },
      { name: 'settings', icon: '⚙️', label: 'Settings', keys: 'Win+I' },
      { name: 'minimize_all', icon: '⬇️', label: 'Minimize', keys: 'Win+M' },
      { name: 'emoji', icon: '😀', label: 'Emoji', keys: 'Win+.' },
      { name: 'clipboard_history', icon: '📝', label: 'Clip History', keys: 'Win+V' },
    ];

    grid.innerHTML = hotkeys.map(hk => `
      <button class="hotkey-btn" onclick="InputPage.sendHotkey('${hk.name}')">
        <span class="icon">${hk.icon}</span>
        ${hk.label}
        <span class="keys">${hk.keys}</span>
      </button>
    `).join('');
  },

  sendHotkey(name) {
    Connection.send({ type: 'preset_hotkey', name });
    Toast.show(`Hotkey: ${name.replace(/_/g, ' ')}`, 'info');
  },
};
