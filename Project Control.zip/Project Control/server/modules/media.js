// PC Commander - Media & Audio Module
// Uses the persistent PS helper from input.js for media keys
const { exec } = require('child_process');
const loudness = require('loudness');
const input = require('./input');

// Media key VK codes
const MEDIA_VK = {
  'play_pause': 0xB3,
  'next': 0xB0,
  'prev': 0xB1,
  'stop': 0xB2,
  'vol_up': 0xAF,
  'vol_down': 0xAE,
  'vol_mute': 0xAD,
};

const media = {
  async getVolume() {
    try {
      const volume = await loudness.getVolume();
      const muted = await loudness.getMuted();
      return { volume, muted };
    } catch (err) {
      return { volume: 0, muted: false, error: err.message };
    }
  },

  async setVolume(level) {
    try {
      const vol = Math.max(0, Math.min(100, parseInt(level)));
      await loudness.setVolume(vol);
      return { success: true, volume: vol };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },

  async toggleMute() {
    try {
      const muted = await loudness.getMuted();
      await loudness.setMuted(!muted);
      return { success: true, muted: !muted };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },

  async setMuted(muted) {
    try {
      await loudness.setMuted(muted);
      return { success: true, muted };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },

  // Send media key using the persistent PS helper (instant, no process spawn)
  async sendMediaKey(key) {
    const vk = MEDIA_VK[key];
    if (!vk) return { success: false, error: 'Unknown media key' };

    try {
      const result = await input.sendMediaKey(vk);
      return { success: result.success, key };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },

  // Get audio devices
  getAudioDevices() {
    return new Promise((resolve, reject) => {
      const psScript = `Get-CimInstance Win32_SoundDevice | Select-Object Name, Status, DeviceID | ConvertTo-Json`;
      exec(`powershell -NoProfile -Command "${psScript}"`, (err, stdout) => {
        if (err) reject(err);
        else {
          try {
            const devices = JSON.parse(stdout);
            resolve(Array.isArray(devices) ? devices : [devices]);
          } catch (e) {
            resolve([]);
          }
        }
      });
    });
  },
};

module.exports = media;
