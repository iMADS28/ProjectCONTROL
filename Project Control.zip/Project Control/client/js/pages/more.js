// PC Commander - More Page (Screenshot, Clipboard, Settings)
const MorePage = {
  initialized: false,

  init() {
    if (this.initialized) return;
    this.initialized = true;
  },

  switchTab(tab) {
    document.querySelectorAll('#page-more .tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('#page-more .tab-content').forEach(tc => tc.classList.remove('active'));
    document.getElementById(`tab-${tab}`).classList.add('active');
    event.target.classList.add('active');

    if (tab === 'clipboard') {
      this.readClipboard();
    }
    if (tab === 'settings') {
      this.loadConnectionInfo();
    }
  },

  // ---- Screenshot ----
  async captureScreenshot() {
    const container = document.getElementById('screenshot-container');
    container.innerHTML = '<div class="loading-overlay"><div class="spinner"></div> Capturing...</div>';

    try {
      const result = await Connection.api('/api/screenshot');
      if (result.success) {
        container.innerHTML = `
          <img class="screenshot-img" src="${result.data}" alt="Screenshot" onclick="MorePage.openScreenshotFullscreen(this.src)">
          <p style="color:var(--text-tertiary); font-size:0.75rem; margin-top:8px;">Tap image to view fullscreen • Size: ${(result.size / 1024).toFixed(0)} KB</p>
        `;
        Toast.show('Screenshot captured', 'success');
      } else {
        container.innerHTML = `<p style="color:var(--danger);">Failed: ${result.error}</p>`;
      }
    } catch (err) {
      container.innerHTML = `<p style="color:var(--danger);">Capture failed: ${err.message}</p>`;
    }
  },

  openScreenshotFullscreen(src) {
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.9);z-index:2000;display:flex;align-items:center;justify-content:center;cursor:pointer;';
    overlay.onclick = () => overlay.remove();
    overlay.innerHTML = `<img src="${src}" style="max-width:95%;max-height:95%;object-fit:contain;border-radius:8px;">`;
    document.body.appendChild(overlay);
  },

  // ---- Clipboard ----
  async readClipboard() {
    try {
      const result = await Connection.api('/api/clipboard');
      const textarea = document.getElementById('clipboard-text');
      if (result.success) {
        textarea.value = result.content;
      }
    } catch (err) {
      Toast.show('Failed to read clipboard', 'error');
    }
  },

  async writeClipboard() {
    const textarea = document.getElementById('clipboard-text');
    const content = textarea.value;
    if (!content) {
      Toast.show('Nothing to send', 'warning');
      return;
    }

    try {
      const result = await Connection.api('/api/clipboard', {
        method: 'POST',
        body: JSON.stringify({ content }),
      });
      if (result.success) {
        Toast.show('Clipboard updated on PC', 'success');
      }
    } catch (err) {
      Toast.show('Failed to write clipboard', 'error');
    }
  },

  async clearClipboard() {
    try {
      await Connection.api('/api/clipboard', { method: 'DELETE' });
      document.getElementById('clipboard-text').value = '';
      Toast.show('Clipboard cleared', 'success');
    } catch (err) {
      Toast.show('Failed to clear clipboard', 'error');
    }
  },

  // ---- Settings ----
  async saveThresholds() {
    const thresholds = {
      CPU_THRESHOLD: parseInt(document.getElementById('threshold-cpu').value) || 90,
      RAM_THRESHOLD: parseInt(document.getElementById('threshold-ram').value) || 90,
      DISK_THRESHOLD: parseInt(document.getElementById('threshold-disk').value) || 90,
      TEMP_THRESHOLD: parseInt(document.getElementById('threshold-temp').value) || 85,
    };

    try {
      await Connection.api('/api/alerts/thresholds', {
        method: 'POST',
        body: JSON.stringify(thresholds),
      });
      Toast.show('Thresholds saved', 'success');
    } catch (err) {
      Toast.show('Failed to save thresholds', 'error');
    }
  },

  loadConnectionInfo() {
    const el = document.getElementById('connection-info');
    if (!el) return;
    el.innerHTML = `
      <div class="info-row">
        <span class="info-label">Server</span>
        <span class="info-value">${location.host}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Protocol</span>
        <span class="info-value">${location.protocol === 'https:' ? 'Secure (HTTPS)' : 'HTTP'}</span>
      </div>
      <div class="info-row">
        <span class="info-label">WebSocket</span>
        <span class="info-value" style="color: ${Connection.isConnected ? 'var(--success)' : 'var(--danger)'}">
          ${Connection.isConnected ? 'Connected' : 'Disconnected'}
        </span>
      </div>
      <div style="margin-top:16px;">
        <button class="btn danger" onclick="Connection.disconnect(); location.reload();">🔌 Disconnect</button>
      </div>
    `;
  },
};
