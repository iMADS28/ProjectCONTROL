// PC Commander - Screenshot Module
const screenshot = require('screenshot-desktop');
const path = require('path');
const fs = require('fs');
const config = require('../config');

// Ensure screenshot directory exists
if (!fs.existsSync(config.SCREENSHOT_DIR)) {
  fs.mkdirSync(config.SCREENSHOT_DIR, { recursive: true });
}

const screenshotModule = {
  async capture() {
    try {
      const img = await screenshot({ format: 'png' });
      const filename = `screenshot-${Date.now()}.png`;
      const filepath = path.join(config.SCREENSHOT_DIR, filename);
      fs.writeFileSync(filepath, img);
      return { success: true, filename, filepath, size: img.length };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },

  async captureBase64() {
    try {
      const img = await screenshot({ format: 'png' });
      const base64 = img.toString('base64');
      return { success: true, data: `data:image/png;base64,${base64}`, size: img.length };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },

  getList() {
    try {
      const files = fs.readdirSync(config.SCREENSHOT_DIR)
        .filter(f => f.endsWith('.png'))
        .sort()
        .reverse()
        .slice(0, 20)
        .map(f => ({
          filename: f,
          path: path.join(config.SCREENSHOT_DIR, f),
          size: fs.statSync(path.join(config.SCREENSHOT_DIR, f)).size,
          created: fs.statSync(path.join(config.SCREENSHOT_DIR, f)).birthtime,
        }));
      return files;
    } catch (err) {
      return [];
    }
  },

  cleanup() {
    try {
      const files = fs.readdirSync(config.SCREENSHOT_DIR);
      files.forEach(f => fs.unlinkSync(path.join(config.SCREENSHOT_DIR, f)));
      return { success: true, message: `Cleaned ${files.length} screenshots.` };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },
};

module.exports = screenshotModule;
