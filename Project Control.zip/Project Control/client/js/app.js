// PC Commander - Main App Controller
const App = {
  currentPage: 'dashboard',
  alertCount: 0,

  async init() {
    // Setup PIN input
    this.setupPinInput();

    // Check for saved token
    const savedToken = localStorage.getItem('pc_commander_token');

    try {
      await Connection.connect();

      if (savedToken) {
        Connection.token = savedToken;
        Connection.send({ type: 'auth_token', token: savedToken });

        Connection.once('auth_result', (msg) => {
          if (msg.success) {
            this.onAuthenticated();
          } else {
            localStorage.removeItem('pc_commander_token');
            this.showLogin();
          }
        });
      } else {
        this.showLogin();
      }
    } catch (err) {
      console.error('Connection failed:', err);
      this.showLogin();
    }

    // Listen for alerts
    Connection.on('system_stats', (msg) => {
      if (msg.alerts && msg.alerts.length > 0) {
        this.updateAlertBadge(msg.alerts.length);
      }
    });
  },

  // ---- Authentication ----
  setupPinInput() {
    const digits = document.querySelectorAll('.pin-digit');
    digits.forEach((input, i) => {
      input.addEventListener('input', (e) => {
        const val = e.target.value;
        if (val && i < digits.length - 1) {
          digits[i + 1].focus();
        }
        // Auto-submit when all digits filled
        if (i === digits.length - 1 && val) {
          this.handleLogin();
        }
      });

      input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && !e.target.value && i > 0) {
          digits[i - 1].focus();
        }
      });

      // Handle paste
      input.addEventListener('paste', (e) => {
        e.preventDefault();
        const paste = (e.clipboardData || window.clipboardData).getData('text');
        const chars = paste.split('').filter(c => /\d/.test(c));
        chars.forEach((char, j) => {
          if (digits[i + j]) {
            digits[i + j].value = char;
          }
        });
        if (chars.length > 0) {
          const lastIdx = Math.min(i + chars.length, digits.length) - 1;
          digits[lastIdx].focus();
          if (lastIdx === digits.length - 1) this.handleLogin();
        }
      });
    });

    // Login button
    document.getElementById('login-btn').addEventListener('click', () => this.handleLogin());
  },

  async handleLogin() {
    const digits = document.querySelectorAll('.pin-digit');
    const pin = Array.from(digits).map(d => d.value).join('');

    if (pin.length < 4) {
      this.showLoginError('Enter all 4 digits');
      return;
    }

    const btn = document.getElementById('login-btn');
    btn.textContent = 'Connecting...';
    btn.disabled = true;

    try {
      // Ensure WebSocket is connected
      if (!Connection.isConnected) {
        await Connection.connect();
      }

      await Connection.authenticate(pin);
      this.onAuthenticated();
    } catch (err) {
      this.showLoginError(err.error || 'Authentication failed');
      btn.textContent = 'Connect';
      btn.disabled = false;
      // Clear PIN
      digits.forEach(d => d.value = '');
      digits[0].focus();
    }
  },

  showLoginError(msg) {
    const el = document.getElementById('login-error');
    el.textContent = msg;
    el.style.animation = 'none';
    el.offsetHeight; // Trigger reflow
    el.style.animation = 'shake 0.4s ease';
  },

  showLogin() {
    document.getElementById('login-screen').classList.remove('hidden');
    document.getElementById('main-app').classList.add('hidden');
    setTimeout(() => {
      document.querySelector('.pin-digit').focus();
    }, 500);
  },

  onAuthenticated() {
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('main-app').classList.remove('hidden');

    // Initialize all pages
    Dashboard.init();
    Toast.show('Connected to PC!', 'success');
  },

  // ---- Navigation ----
  navigate(page) {
    // Update nav buttons
    document.querySelectorAll('.nav-item').forEach(item => {
      item.classList.toggle('active', item.dataset.page === page);
    });

    // Update pages
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const pageEl = document.getElementById(`page-${page}`);
    if (pageEl) pageEl.classList.add('active');

    this.currentPage = page;

    // Initialize page-specific content on first visit
    switch (page) {
      case 'dashboard': Dashboard.init(); break;
      case 'media': Media.init(); break;
      case 'input': InputPage.init(); break;
      case 'apps': AppsPage.init(); break;
      case 'files': FilesPage.init(); break;
      case 'more': MorePage.init(); break;
    }
  },

  // ---- Alerts ----
  updateAlertBadge(count) {
    this.alertCount = count;
    const badge = document.getElementById('alert-count');
    if (count > 0) {
      badge.textContent = count;
      badge.classList.remove('hidden');
    } else {
      badge.classList.add('hidden');
    }
  },

  showAlerts() {
    Connection.api('/api/alerts').then(data => {
      let content = '';
      if (data.active && data.active.length > 0) {
        content += '<div style="margin-bottom:16px;"><strong style="color:var(--warning);">Active Alerts</strong></div>';
        content += data.active.map(a => `
          <div style="padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.06); font-size:0.85rem;">
            ${a.severity === 'critical' ? '🔴' : '🟡'} ${a.message}
          </div>
        `).join('');
      } else {
        content = '<p style="color:var(--text-secondary); text-align:center; padding:20px;">✅ No active alerts</p>';
      }

      Modal.show('🔔 System Alerts', content, [
        { label: 'Clear History', class: 'danger', onclick: "Connection.api('/api/alerts/history', {method:'DELETE'}); Modal.close(); Toast.show('History cleared', 'info');" },
      ]);
    });
  },
};

// Boot the app
document.addEventListener('DOMContentLoaded', () => App.init());
