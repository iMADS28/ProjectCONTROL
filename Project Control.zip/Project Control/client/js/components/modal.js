// PC Commander - Modal Component
const Modal = {
  show(title, content, actions = []) {
    // Remove existing modal
    this.close();

    const actionsHtml = actions.map(a =>
      `<button class="btn ${a.class || ''}" onclick="${a.onclick}">${a.label}</button>`
    ).join('');

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.id = 'modal-overlay';
    overlay.onclick = (e) => {
      if (e.target === overlay) this.close();
    };

    overlay.innerHTML = `
      <div class="modal">
        <h3 class="modal-title">${title}</h3>
        <div class="modal-body">${content}</div>
        <div class="modal-actions">
          <button class="btn" onclick="Modal.close()">Cancel</button>
          ${actionsHtml}
        </div>
      </div>
    `;

    document.body.appendChild(overlay);
  },

  confirm(title, message, onConfirm) {
    this.show(title, `<p style="color:var(--text-secondary); font-size:0.9rem;">${message}</p>`, [
      { label: 'Confirm', class: 'primary', onclick: `Modal.close(); (${onConfirm.toString()})()` },
    ]);
  },

  close() {
    const overlay = document.getElementById('modal-overlay');
    if (overlay) overlay.remove();
  },
};
