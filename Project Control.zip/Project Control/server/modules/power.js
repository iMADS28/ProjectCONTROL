// PC Commander - Power Management Module
const { exec } = require('child_process');
const wol = require('wake_on_lan');
const config = require('../config');

const power = {
  shutdown() {
    return new Promise((resolve, reject) => {
      exec('shutdown /s /t 3 /c "PC Commander: Shutting down..."', (err) => {
        if (err) reject(err);
        else resolve({ success: true, message: 'Shutting down in 3 seconds...' });
      });
    });
  },

  restart() {
    return new Promise((resolve, reject) => {
      exec('shutdown /r /t 3 /c "PC Commander: Restarting..."', (err) => {
        if (err) reject(err);
        else resolve({ success: true, message: 'Restarting in 3 seconds...' });
      });
    });
  },

  sleep() {
    return new Promise((resolve, reject) => {
      exec('rundll32.exe powrprof.dll,SetSuspendState 0,1,0', (err) => {
        if (err) reject(err);
        else resolve({ success: true, message: 'Entering sleep mode...' });
      });
    });
  },

  hibernate() {
    return new Promise((resolve, reject) => {
      exec('shutdown /h', (err) => {
        if (err) reject(err);
        else resolve({ success: true, message: 'Hibernating...' });
      });
    });
  },

  lock() {
    return new Promise((resolve, reject) => {
      exec('rundll32.exe user32.dll,LockWorkStation', (err) => {
        if (err) reject(err);
        else resolve({ success: true, message: 'Screen locked.' });
      });
    });
  },

  cancelShutdown() {
    return new Promise((resolve, reject) => {
      exec('shutdown /a', (err) => {
        if (err) reject(err);
        else resolve({ success: true, message: 'Shutdown cancelled.' });
      });
    });
  },

  scheduleShutdown(seconds) {
    return new Promise((resolve, reject) => {
      exec(`shutdown /s /t ${seconds} /c "PC Commander: Scheduled shutdown"`, (err) => {
        if (err) reject(err);
        else resolve({ success: true, message: `Shutdown scheduled in ${seconds} seconds.` });
      });
    });
  },

  wakeOnLan(mac) {
    const macAddress = mac || config.WOL_MAC;
    return new Promise((resolve, reject) => {
      wol.wake(macAddress, (err) => {
        if (err) reject(err);
        else resolve({ success: true, message: `WOL magic packet sent to ${macAddress}` });
      });
    });
  },

  logoff() {
    return new Promise((resolve, reject) => {
      exec('shutdown /l', (err) => {
        if (err) reject(err);
        else resolve({ success: true, message: 'Logging off...' });
      });
    });
  },
};

module.exports = power;
