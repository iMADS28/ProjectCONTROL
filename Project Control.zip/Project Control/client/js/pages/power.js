// PC Commander - Power Page
const Power = {
  async action(type) {
    const confirmActions = ['shutdown', 'restart', 'logoff', 'hibernate'];

    const labels = {
      shutdown: '⏻ Shutdown your PC?',
      restart: '🔄 Restart your PC?',
      sleep: '😴 Put PC to sleep?',
      hibernate: '❄️ Hibernate your PC?',
      lock: '🔒 Lock screen?',
      logoff: '🚪 Log off?',
      wol: '📡 Send Wake-on-LAN packet?',
      cancel: '✋ Cancel scheduled shutdown?',
    };

    const execute = async () => {
      try {
        const result = await Connection.api(`/api/power/${type}`, {
          method: 'POST',
          body: JSON.stringify({}),
        });
        if (result.success) {
          Toast.show(result.message, 'success');
        } else {
          Toast.show(result.error || 'Action failed', 'error');
        }
      } catch (err) {
        Toast.show('Failed to execute: ' + err.message, 'error');
      }
    };

    if (confirmActions.includes(type)) {
      Modal.confirm(
        labels[type] || 'Confirm Action',
        'This action will be executed on your PC. Are you sure?',
        execute
      );
    } else {
      execute();
    }
  },

  async schedule() {
    const minutes = parseInt(document.getElementById('schedule-time').value) || 60;
    const seconds = minutes * 60;

    Modal.confirm(
      '⏰ Schedule Shutdown',
      `Your PC will shut down in ${minutes} minutes. Continue?`,
      async () => {
        try {
          const result = await Connection.api('/api/power/schedule', {
            method: 'POST',
            body: JSON.stringify({ seconds }),
          });
          if (result.success) {
            Toast.show(result.message, 'success');
          } else {
            Toast.show(result.error || 'Schedule failed', 'error');
          }
        } catch (err) {
          Toast.show('Failed to schedule: ' + err.message, 'error');
        }
      }
    );
  },
};
